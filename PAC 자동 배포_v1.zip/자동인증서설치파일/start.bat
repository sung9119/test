net stop PcaSvc
reg import pac_enable.reg
certmgr.exe -add SEHZ.crt -c -s -r localMachine root
net start PcaSvc