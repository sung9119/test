net stop PcaSvc
reg import pac_enable.reg
certmgr.exe -add SBioL.cer -c -s -r localMachine root
net start PcaSvc