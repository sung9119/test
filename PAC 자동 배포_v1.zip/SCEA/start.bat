net stop PcaSvc
reg import pac_enable.reg
certmgr.exe -add seca_proxy.crts -c -s -r localMachine root
net start PcaSvc